package com.realweatherultra.tornado;

import com.realweatherultra.RealWeatherUltra;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.network.syncher.SynchedEntityData;

/**
 * A tornado funnel on the ground under a thunderstorm. It drifts with the wind,
 * is drawn as a spiral of cloud particles from the storm base down to the ground,
 * and disappears after a while. Created only by StormSpawner, never under an anvil.
 */
public class TornadoEntity extends Entity {
    /** Lifetime in ticks (about 60 seconds). */
    public static final int LIFETIME = 1200;
    /** Height of the storm base above the ground, in blocks. */
    public static final double STORM_BASE = 120.0;

    private int age = 0;
    private double driftX;
    private double driftZ;

    public TornadoEntity(EntityType<? extends TornadoEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    /** Wind drift in blocks per tick, set by the spawner. */
    public void setDrift(double x, double z) {
        this.driftX = x;
        this.driftZ = z;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
    }

    @Override
    public void tick() {
        super.tick();
        age++;
        if (age > LIFETIME) {
            discard();
            return;
        }
        if (level() instanceof ServerLevel server) {
            double nx = getX() + driftX;
            double nz = getZ() + driftZ;
            int bx = (int) Math.floor(nx);
            int bz = (int) Math.floor(nz);
            if (server.hasChunkAt(new net.minecraft.core.BlockPos(bx, 0, bz))) {
                int groundY = server.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, bx, bz);
                setPos(nx, groundY, nz);
            }
            spawnFunnel(server);
        }
    }

    /** A spiral of cloud particles from the ground up to the storm base. */
    private void spawnFunnel(ServerLevel server) {
        double h = STORM_BASE;
        for (int i = 0; i < 12; i++) {
            double f = server.random.nextDouble();
            double y = getY() + f * h;
            double radius = 1.0 + 4.0 * f;
            double angle = (age * 0.35) + f * 9.0 + i * 0.52;
            double px = getX() + Math.cos(angle) * radius;
            double pz = getZ() + Math.sin(angle) * radius;
            server.sendParticles(ParticleTypes.CLOUD, px, y, pz, 1, 0.0, 0.0, 0.0, 0.02);
        }
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.age = tag.getInt("Age");
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Age", age);
    }
}
