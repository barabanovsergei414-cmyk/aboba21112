package com.realweatherultra.storm;

import com.realweatherultra.RealWeatherUltra;
import com.realweatherultra.tornado.TornadoEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;

/**
 * Every 200 ticks, during a thunderstorm in the overworld, a tornado may form
 * under the storm, 150-400 blocks from a random player. It is never placed
 * on a player's position and never created inside a stored structure.
 */
public class StormSpawner {
    private static final int INTERVAL = 200;
    private static final double CHANCE = 0.25;

    @SubscribeEvent
    public void onLevelTick(LevelTickEvent.Post event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;
        if (level.getGameTime() % INTERVAL != 0) return;
        if (!level.isThundering()) return;
        if (level.players().isEmpty()) return;
        if (level.random.nextDouble() > CHANCE) return;

        ServerPlayer player = level.players().get(level.random.nextInt(level.players().size()));
        double angle = level.random.nextDouble() * Math.PI * 2.0;
        double dist = 150.0 + level.random.nextDouble() * 250.0;
        double x = player.getX() + Math.cos(angle) * dist;
        double z = player.getZ() + Math.sin(angle) * dist;

        BlockPos col = BlockPos.containing(x, 0, z);
        if (!level.hasChunkAt(col)) return;
        int groundY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, col.getX(), col.getZ());

        TornadoEntity tornado = new TornadoEntity(RealWeatherUltra.TORNADO.get(), level);
        tornado.setPos(x, groundY, z);
        double windAngle = level.random.nextDouble() * Math.PI * 2.0;
        tornado.setDrift(Math.cos(windAngle) * 0.05, Math.sin(windAngle) * 0.05);
        level.addFreshEntity(tornado);
    }
}
